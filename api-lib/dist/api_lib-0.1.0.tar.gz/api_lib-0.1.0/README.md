
```
video-storage[ alex @ alex ] ./api-lib (master)$ poetry add aio-pika==9.5.4

Updating dependencies
Resolving dependencies... (0.3s)

Package operations: 0 installs, 7 updates, 0 removals

  - Downgrading certifi (2025.1.31 -> 2024.12.14)
  - Updating httpcore (0.17.3 -> 1.0.7)
  - Updating pydantic-core (2.23.4 -> 2.27.2)
  - Updating uvicorn (0.30.6 -> 0.34.0)
  - Updating python-multipart (0.0.9 -> 0.0.20)
  - Updating pydantic (2.9.2 -> 2.10.5)
  - Updating httpx (0.24.1 -> 0.28.1)
```