from pydantic import BaseModel, Field
from bson import ObjectId
from pydantic_core import core_schema
# from pydantic.json_schema import JsonSchemaValue
from typing import Any
import datetime

class PyObjectId:

    @classmethod
    def validate_object_id(cls, v: Any, handler) -> ObjectId:
        if isinstance(v, ObjectId):
            return v
        s = handler(v)
        if ObjectId.is_valid(s):
            return ObjectId(s)
        else:
            raise ValueError("Invalid ObjectId")

    @classmethod
    def __get_pydantic_core_schema__(cls, source_type, _handler) -> core_schema.CoreSchema:
        # assert source_type is ObjectId
        # logger.debug(f'source_type type: {source_type}  {type(source_type)}')
        return core_schema.no_info_wrap_validator_function(
            cls.validate_object_id, 
            core_schema.str_schema(), 
            serialization=core_schema.to_string_ser_schema(),
        )

    # @classmethod
    # def __get_pydantic_json_schema__(cls, _core_schema, handler) -> JsonSchemaValue:
        # return handler(core_schema.str_schema())

    @classmethod
    def __get_pydantic_json_schema__(cls, schema, model_field) -> dict:
        """Generate a custom json schema for ObjectId, telling Pydantic the type is string with UUID format.
        """
        return {"type": "string", "format": "uuid"}

master_encoders = {
    ObjectId: str,
    PyObjectId: str,
    datetime.datetime: lambda t: t.isoformat(),
}
class BaseConfig(BaseModel):
    class Config:
        populate_by_name = True
        arbitrary_types_allowed = True
        json_encoders = master_encoders

class MetadataItem(BaseModel):
    id: str = Field(
        ..., 
        description=(
            'Video ID which is bson.ObjectId generated randomly on upload'
        ),
    )
    name: str = Field(
        ..., 
        description=(
            'Filename of uploaded file'
        ),
    )
    user_id: str | None = Field(
        default_factory=lambda: '', 
        description=(
            'MongoDB user _id: ObjectId as str '
            'generated on registration by auth-user service. '
        ),
    )
    album_id: str | None = Field(
        default_factory=lambda: None, 
        description=(
            'string ObjectId of the album this video belongs to. '
        ),
    )
    album_name: str | None = Field(
        default_factory=lambda: None, 
        description=(
            'Name of the ablum for this image or video. '
        ),
    )
    file_size: str | int | None = Field(
        default_factory=lambda: None, 
        description=(
            'Size of the uploaded file. '
        ),
    )
    is_public: bool = Field(
        default_factory=lambda: False, 
        description=(
            'Is it public or private'
        ),
    )

class VideoSchema(MetadataItem, BaseConfig):
    """
    used in:
        - metadata
    """
    # id: Annotated[ObjectId, PyObjectId]
    id: PyObjectId | None = Field(
        default_factory=lambda: None, 
        description="The ID of the video to retrieve",
        alias='_id')
    views: int = Field(
        default_factory=lambda: 0, 
        description="Count of video views")
    downloads: int = Field(
        default_factory=lambda: 0, 
        description="Count of the number of downloads")
    likes: int = Field(
        default_factory=lambda: 0, 
        description="Count of likes")
    dislikes: int = Field(
        default_factory=lambda: 0, 
        description="Count of dislikes")

class LikeSchema(BaseModel):
    likes: int = Field(
        default_factory=lambda: 0, 
        description="Count of likes")
    dislikes: int = Field(
        default_factory=lambda: 0, 
        description="Count of dislikes")

class VideoUpdateSchema(BaseConfig):
    """
    used in:
        - metadata
    """
    is_public: bool = Field(
        default_factory=lambda: None, 
        description=(
            'Is it public or private'
        ),
    )
    album_id: str | None = Field(
        default_factory=lambda: None, 
        description=(
            'FK of album this video belongs to. '
        ),
    )
    album_name: str | None = Field(
        default_factory=lambda: None, 
        description=(
            'album name this video belongs to. '
        ),
    )

class AlbumUpdateSchema(
    VideoUpdateSchema, 
    BaseConfig# NOTE: do i need this if inherited from VideoUpdateSchema
):
    """
    used in:
        - metadata
    """
    pass

class AlbumBaseSchema(BaseConfig):
    """
    used in:
        - metadata
    """
    user_id: str | None = Field(
        default_factory=lambda: None, 
        description=(
            'MongoDB user _id: ObjectId as str '
            'generated on registration by auth-user service. '
        ),
    )
    album_name: str | None = Field(
        default_factory=lambda: None, 
        description="Name of the album")
    count: int | None = Field(
        default_factory=lambda: None, 
        description="Count of videos in the album")
    album_size: int | None = Field(
        default_factory=lambda: None, 
        description="Total size in memory of all videos in the album")
    is_public: bool = Field(
        default_factory=lambda: False, 
        description=(
            'Is it public or private'
        ),
    )

class AlbumSchema(AlbumBaseSchema, BaseConfig):
    """
    used in:
        - metadata
    """
    id: PyObjectId = Field(
        default_factory=lambda: None, 
        description="The ID of the video to retrieve",
        alias='_id')

class AlbumCreateSchema(AlbumBaseSchema, BaseConfig):
    """
    used in:
        - metadata
    """
    user_id: str = Field(
        ..., 
        description=(
            'MongoDB user _id: ObjectId as str '
            'generated on registration by auth-user service. '
        ),
    )

class MetadataList(BaseModel):
    video: MetadataItem

class Video(BaseConfig):
    video: VideoSchema

class Videos(BaseConfig):
    videos: list[VideoSchema]
    total_count: int

class Albums(BaseConfig):
    albums: list[AlbumSchema]
    total_count: int

class PartModel(BaseModel):
    ETag: str
    PartNumber: int

class CompletePartSchema(BaseModel):
    album_name: str | None
    video_id: str
    upload_id: str
    file_name: str
    file_size: str | int
    parts: list[PartModel]

class ErrorSchema(BaseModel):
    message: str | None = Field(
        default_factory=lambda: '', 
        description='Developer written message. May be displayed to the user on frontend.')
    error: str | None = Field(
        default_factory=lambda: '', 
        description='System generated message, usually from an exception. Always logged.')
    color: str | None = Field(
        default_factory=lambda: '', 
        description='Color for frontend developer user feedback.')
    class Config:
        populate_by_name = True
        json_schema_extra = {
            "examples": [
                {
                    "message": "Developer error msg ",
                    "error": "Exception error msg",
                    "color": "red",
                }
            ]
        }

class FilterParams(BaseModel):
    model_config = {"extra": "forbid"}
    skip: int = Field(0, ge=0),
    limit: int = Field(100, gt=0, le=100)